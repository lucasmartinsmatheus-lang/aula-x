// Classe base
class Pessoa {
    String nome;
    int idade;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public void apresentar() {
        System.out.println("Ola, meu nome eh " + this.nome + " e tenho " + this.idade + " anos.");
    }
}

// Classe Aluno herdando de Pessoa
class Aluno extends Pessoa {
    String curso;

    public Aluno(String nome, int idade, String curso) {
        super(nome, idade); 
        this.curso = curso;
    }

    public void estudar() {
        System.out.println(this.nome + " esta estudando no curso de " + this.curso + ".");
    }
}

// Classe Professor herdando de Pessoa
class Professor extends Pessoa {
    String disciplina;

    public Professor(String nome, int idade, String disciplina) {
        super(nome, idade);
        this.disciplina = disciplina;
    }

    public void ensinar() {
        System.out.println("O(A) professor(a) " + this.nome + " esta ensinando " + this.disciplina + ".");
    }
}

// Classe principal para rodar os testes
public class exercicio3 {
    public static void main(String[] args) {
        
        System.out.println("--- Testando Objeto Pessoa ---");
        Pessoa pessoa1 = new Pessoa("Ana", 25);
        pessoa1.apresentar();

        System.out.println("\n--- Testando Objeto Aluno ---");
        Aluno aluno1 = new Aluno("Carlos", 20, "Ciencia da Computacao");
        aluno1.apresentar(); // Herdado de Pessoa
        aluno1.estudar();    // Proprio de Aluno

        System.out.println("\n--- Testando Objeto Professor ---");
        Professor prof1 = new Professor("Sonia", 42, "Programacao Orientada a Objetos");
        prof1.apresentar(); // Herdado de Pessoa
        prof1.ensinar();    // Proprio de Professor
    }
}