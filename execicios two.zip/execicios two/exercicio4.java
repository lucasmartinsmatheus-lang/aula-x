// Classe base do sistema
class Publicacao {
    String titulo;
    int ano;

    public Publicacao(String titulo, int ano) {
        this.titulo = titulo;
        this.ano = ano;
    }

    public void exibirInformacoes() {
        System.out.println("Titulo: " + this.titulo);
        System.out.println("Ano: " + this.ano);
    }
}

// Classe Livro que herda de Publicacao
class Livro extends Publicacao {
    String autor;

    public Livro(String titulo, int ano, String autor) {
        super(titulo, ano);
        this.autor = autor;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Autor: " + this.autor);
    }
}

// Classe Revista que herda de Publicacao
class Revista extends Publicacao {
    int edicao;

    public Revista(String titulo, int ano, int edicao) {
        super(titulo, ano);
        this.edicao = edicao;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Edicao: " + this.edicao);
    }
}

// Classe principal para rodar o programa
public class exercicio4 {
    public static void main(String[] args) {
        
        System.out.println("--- Dados do Livro ---");
        Livro livro1 = new Livro("O Alquimista", 1988, "Paulo Coelho");
        livro1.exibirInformacoes();

        System.out.println("\n--- Dados da Revista ---");
        Revista revista1 = new Revista("Mundo Estranho", 2022, 150);
        revista1.exibirInformacoes();
    }
}