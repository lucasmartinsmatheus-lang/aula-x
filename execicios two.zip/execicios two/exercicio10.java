import java.util.Locale;

// Ajustado para o nome do seu novo arquivo: exercicio10.java
public class exercicio10 {
    
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);

        System.out.println("--- REGISTRO DE ALUNOS ---");
        // Criando dois alunos (Corrigido o espaco entre Aluno e aluno2)
        Aluno aluno1 = new Aluno("Carlos Souza", 16, "ALU101");
        Aluno aluno2 = new Aluno("Ana Costa", 17, "ALU102");

        aluno1.mostrarDados();
        System.out.println();
        aluno2.mostrarDados();

        System.out.println("\n--- REGISTRO DE PROFESSORES ---");
        // Criando dois professores
        Professor prof1 = new Professor("Roberto Alves", 45, "Matematica", 3500.00);
        Professor prof2 = new Professor("Maria Silva", 38, "Historia", 3650.50);

        prof1.mostrarDados();
        System.out.println();
        prof2.mostrarDados();
    }
}

// Classe Base
class Pessoa {
    private String nome;
    private int idade;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public void mostrarDados() {
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade + " anos");
    }
}

// Subclasse Aluno
class Aluno extends Pessoa {
    private String matricula;

    public Aluno(String nome, int idade, String matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }

    @Override
    public void mostrarDados() {
        super.mostrarDados();
        System.out.println("Matricula: " + this.matricula);
    }
}

// Subclasse Professor
class Professor extends Pessoa {
    private String disciplina;
    private double salario;

    public Professor(String nome, int idade, String disciplina, double salario) {
        super(nome, idade);
        this.disciplina = disciplina;
        this.salario = salario;
    }

    @Override
    public void mostrarDados() {
        super.mostrarDados();
        System.out.println("Disciplina: " + this.disciplina);
        System.out.printf("Salario: R$ %.2f%n", this.salario);
    }
}