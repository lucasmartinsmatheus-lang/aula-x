// Classe base
class Funcionario {
    String nome;
    double salario;

    public Funcionario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public void mostrarDados() {
        System.out.println("Nome: " + this.nome);
        System.out.println("Salario: " + this.salario);
    }
}

// Classe Gerente herdando de Funcionario
class Gerente extends Funcionario {
    String departamento;

    public Gerente(String nome, double salario, String departamento) {
        super(nome, salario);
        this.departamento = departamento;
    }

    // Sobrescrita do metodo para mostrar os dados especificos do Gerente
    @Override
    public void mostrarDados() {
        super.mostrarDados();
        System.out.println("Departamento: " + this.departamento);
    }

    public void autorizarCompra(double valor) {
        System.out.println("O gerente " + this.nome + " autorizou a compra no valor de " + valor);
    }
}

// Classe principal para rodar os testes
public class exercicio6 {
    public static void main(String[] args) {
        
        System.out.println("--- Dados do Funcionario ---");
        Funcionario func1 = new Funcionario("Lucas", 3000.0);
        func1.mostrarDados();

        System.out.println("\n--- Dados do Gerente ---");
        Gerente gerente1 = new Gerente("Amanda", 7500.0, "Financeiro");
        gerente1.mostrarDados(); // Mostra dados do Funcionario + departamento
        gerente1.autorizarCompra(1500.0); // Metodo exclusivo do Gerente
    }
}