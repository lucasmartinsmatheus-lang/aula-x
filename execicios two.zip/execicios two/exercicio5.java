// Classe base
class Veiculo {
    String marca;
    String modelo;

    public Veiculo(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    public void ligar() {
        System.out.println("O veiculo " + this.marca + " " + this.modelo + " esta ligado.");
    }
}

// Classe Carro herdando de Veiculo
class Carro extends Veiculo {
    int qtdPortas;

    public Carro(String marca, String modelo, int qtdPortas) {
        super(marca, modelo);
        this.qtdPortas = qtdPortas;
    }

    public void abrirPorta() {
        System.out.println("As " + this.qtdPortas + " portas do carro estao abertas.");
    }
}

// Classe principal para execucao dos testes
public class exercicio5 {
    public static void main(String[] args) {
        
        System.out.println("--- Testando Objeto Veiculo ---");
        Veiculo veiculo1 = new Veiculo("Honda", "CB 500");
        veiculo1.ligar(); // Metodo proprio de Veiculo

        System.out.println("\n--- Testando Objeto Carro ---");
        Carro carro1 = new Carro("Toyota", "Corolla", 4);
        carro1.ligar();      // Metodo herdado de Veiculo
        carro1.abrirPorta();  // Metodo proprio de Carro
    }
}