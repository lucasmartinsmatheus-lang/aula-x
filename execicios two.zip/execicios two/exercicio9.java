// A classe principal mantem o nome do arquivo para rodar direto
public class exercicio9 {
    
    public static void main(String[] args) {
        System.out.println("--- Testando os Animais da Clinica ---");

        Animal a1 = new Cachorro("Rex");
        Animal a2 = new Gato("Whiskas");

        // Polimorfismo: cada objeto executa sua propria versao do metodo
        System.out.print(a1.getNome() + " diz: ");
        a1.emitirSom();

        System.out.print(a2.getNome() + " diz: ");
        a2.emitirSom();
    }
}

// Classe Base
class Animal {
    private String nome;

    public Animal(String nome) {
        this.nome = nome;
    }

    public void emitirSom() {
        System.out.println("Som generico de animal");
    }

    public String getNome() {
        return nome;
    }
}

// Subclasse Cachorro
class Cachorro extends Animal {

    public Cachorro(String nome) {
        super(nome); // Passa o nome para o construtor da classe pai
    }

    @Override
    public void emitirSom() {
        System.out.println("Au Au!");
    }
}

// Subclasse Gato
class Gato extends Animal {

    public Gato(String nome) {
        super(nome); // Passa o nome para o construtor da classe pai
    }

    @Override
    public void emitirSom() {
        System.out.println("Miau!");
    }
}