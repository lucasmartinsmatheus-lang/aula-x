import java.util.Locale;

// A classe principal DEVE ter o mesmo nome do arquivo: exercicio7.java
public class exercicio7 {
    
    public static void main(String[] args) {
        // Configura o ponto decimal para o padrao americano nos prints
        Locale.setDefault(Locale.US);

        System.out.println("--- Criando Conta Corrente com R$ 100 de saldo e R$ 500 de limite ---");
        ContaCorrente cc = new ContaCorrente("Joao Silva", 100.0, 500.0);
        cc.consultarSaldo();

        System.out.println("\n--- Tentando sacar R$ 150 (saldo insuficiente) ---");
        cc.sacar(150.0);

        System.out.println("\n--- Usando R$ 200 do limite do banco ---");
        cc.usarLimite(200.0);
        cc.consultarSaldo();

        System.out.println("\n--- Sacando R$ 150 agora que o saldo aumentou ---");
        cc.sacar(150.0);
        cc.consultarSaldo();

        System.out.println("\n--- Depositando R$ 250 (deve pagar o limite primeiro) ---");
        cc.depositar(250.0);
        cc.consultarSaldo();
    }
}

// Classe Base
class ContaBancaria {
    private String titular;
    protected double saldo;

    public ContaBancaria(String titular, double saldoInicial) {
        this.titular = titular;
        this.saldo = saldoInicial;
    }

    public void depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
            System.out.printf("Deposito de R$ %.2f realizado com sucesso.%n", valor);
        } else {
            System.out.println("Erro: O valor do deposito deve ser maior que zero.");
        }
    }

    public boolean sacar(double valor) {
        if (valor <= 0) {
            System.out.println("Erro: O valor do saque deve ser maior que zero.");
            return false;
        }
        if (valor <= this.saldo) {
            this.saldo -= valor;
            System.out.printf("Saque de R$ %.2f realizado com sucesso.%n", valor);
            return true;
        }
        System.out.println("Erro: Saldo insuficiente.");
        return false;
    }

    public double consultarSaldo() {
        System.out.printf("Titular: %s | Saldo: R$ %.2f%n", this.titular, this.saldo);
        return this.saldo;
    }

    public String getTitular() {
        return titular;
    }
}

// Classe Filha
class ContaCorrente extends ContaBancaria {
    private double limiteMaximo;
    private double limiteUsado;

    public ContaCorrente(String titular, double saldoInicial, double limiteMaximo) {
        super(titular, saldoInicial);
        this.limiteMaximo = limiteMaximo;
        this.limiteUsado = 0.0;
    }

    @Override
    public double consultarSaldo() {
        double limiteDisponivel = this.limiteMaximo - this.limiteUsado;
        System.out.printf("Titular: %s | Saldo: R$ %.2f | Limite Disponivel: R$ %.2f%n", 
                getTitular(), this.saldo, limiteDisponivel);
        return this.saldo;
    }

    public boolean usarLimite(double valor) {
        if (valor <= 0) {
            System.out.println("Erro: O valor para usar do limite deve ser maior que zero.");
            return false;
        }
        double limiteDisponivel = this.limiteMaximo - this.limiteUsado;
        if (valor <= limiteDisponivel) {
            this.limiteUsado += valor;
            this.saldo += valor;
            System.out.printf("Limite de R$ %.2f utilizado. Valor adicionado ao saldo.%n", valor);
            return true;
        }
        System.out.println("Erro: Limite insuficiente.");
        return false;
    }

    @Override
    public void depositar(double valor) {
        if (valor <= 0) {
            System.out.println("Erro: O valor do deposito deve ser maior que zero.");
            return;
        }

        if (this.limiteUsado > 0) {
            if (valor <= this.limiteUsado) {
                this.limiteUsado -= valor;
                System.out.printf("Deposito de R$ %.2f usado para abater o limite usado.%n", valor);
            } else {
                double valorRestante = valor - this.limiteUsado;
                System.out.printf("Deposito de R$ %.2f usado para quitar o limite usado.%n", this.limiteUsado);
                this.limiteUsado = 0.0;
                this.saldo += valorRestante;
                System.out.printf("R$ %.2f adicionados ao saldo positivo.%n", valorRestante);
            }
        } else {
            super.depositar(valor);
        }
    }
}