import java.util.Locale;

// A classe principal mantem o nome do arquivo para rodar direto
public class exercicio8 {
    
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);

        System.out.println("--- Criando um Produto Normal ---");
        Produto p1 = new Produto("Camiseta Algodao", 59.90);
        p1.mostrarProduto();

        System.out.println("\n--- Criando um Produto Eletronico ---");
        ProdutoEletronico p2 = new ProdutoEletronico("Smartphone Celular", 1499.00, 12);
        p2.mostrarProduto();
    }
}

// Classe Base
class Produto {
    private String nome;
    protected double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public void mostrarProduto() {
        System.out.println("Produto: " + this.nome);
        System.out.printf("Preco: R$ %.2f%n", this.preco);
    }

    public String getNome() {
        return nome;
    }
}

// Classe Filha: ProdutoEletronico herda de Produto
class ProdutoEletronico extends Produto {
    private int garantiaMeses;

    public ProdutoEletronico(String nome, double preco, int garantiaMeses) {
        // Super chama o construtor da classe pai (Produto)
        super(nome, preco);
        this.garantiaMeses = garantiaMeses;
    }

    // Sobrescrita do metodo para incluir a garantia do eletronico
    @Override
    public void mostrarProduto() {
        super.mostrarProduto(); // Roda o print do nome e preco original
        System.out.println("Garantia: " + this.garantiaMeses + " meses");
    }
}