// Classe base
class Pessoa {
    String nome;
    int idade;

    // Construtor de Pessoa
    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public void apresentar() {
        System.out.println("Ola, meu nome e " + this.nome + " e tenho " + this.idade + " anos.");
    }
}

// Classe Aluno herdando de Pessoa
class Aluno extends Pessoa {
    String curso;

    // Construtor de Aluno (chama o construtor da Pessoa usando 'super')
    public Aluno(String nome, int idade, String curso) {
        super(nome, idade); 
        this.curso = curso;
    }

    public void estudar() {
        System.out.println(this.nome + " esta estudando no curso de " + this.curso + ".");
    }
}

// Classe principal (deve ter o mesmo nome do arquivo)
public class exercicio2 {
    public static void main(String[] args) {
        
        System.out.println("--- Testando Objeto Pessoa ---");
        Pessoa pessoa1 = new Pessoa("Ana", 25);
        pessoa1.apresentar(); // Método da própria classe

        System.out.println("\n--- Testando Objeto Aluno ---");
        Aluno aluno1 = new Aluno("Carlos", 20, "Ciencia da Computacao");
        aluno1.apresentar(); // Método herdado de Pessoa
        aluno1.estudar();    // Método próprio de Aluno
    }
}