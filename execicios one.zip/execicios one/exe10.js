class PessoaEscolar {
    constructor(nome, idade) {
        this.nome = nome;
        this.idade = idade;
    }

    mostrarDados() {
        console.log(`Nome: ${this.nome}, Idade: ${this.idade}`);
    }
}

class AlunoEscolar extends PessoaEscolar {
    constructor(nome, idade, matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }

    mostrarDados() {
        console.log(`[Aluno] Nome: ${this.nome}, Idade: ${this.idade}, Matricula: ${this.matricula}`);
    }
}

class ProfessorEscolar extends PessoaEscolar {
    constructor(nome, idade, Siape) {
        super(nome, idade);
        this.Siape = Siape;
    }

    mostrarDados() {
        console.log(`[Professor] Nome: ${this.nome}, Idade: ${this.idade}, SIAPE: ${this.Siape}`);
    }
}

console.log("\n--- Teste Questao 10 ---");

const escola = [
    new AlunoEscolar("Lucas", 15, "A01"),
    new AlunoEscolar("Beatriz", 16, "A02"),
    new ProfessorEscolar("Marcos", 50, "P99"),
    new ProfessorEscolar("Ana", 38, "P98")
];

escola.forEach(membro => membro.mostrarDados());