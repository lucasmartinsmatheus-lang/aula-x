class Veiculo {
    constructor(marca, modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    ligar() {
        console.log(`O veiculo ${this.marca} ${this.modelo} esta ligado.`);
    }
}

class Carro extends Veiculo {
    constructor(marca, modelo, portas) {
        super(marca, modelo);
        this.portas = portas;
    }

    abrirPorta() {
        console.log(`Abrindo uma das ${this.portas} portas do carro.`);
    }
}

console.log("\n--- Teste Questao 5 ---");

const meuCarro = new Carro("Toyota", "Corolla", 4);

meuCarro.ligar();
meuCarro.abrirPorta();