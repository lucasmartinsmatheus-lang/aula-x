class Animal {
    constructor(nome) {
        this.nome = nome;
    }

    emitirSom() {
        console.log("O animal emite um som generico.");
    }
}

class Cachorro extends Animal {
    emitirSom() {
        console.log(`${this.nome} diz: Au Au!`);
    }
}

class Gato extends Animal {
    emitirSom() {
        console.log(`${this.nome} diz: Miau!`);
    }
}

console.log("\n--- Teste Questao 9 ---");

const c = new Cachorro("Rex");
const g = new Gato("Felix");

c.emitirSom();
g.emitirSom();