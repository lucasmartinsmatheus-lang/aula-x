class Pessoa {
    constructor(nome, idade) {
        this.nome = nome
        this.idade = idade
    }

    apresentar() {
        console.log(`Ola! Meu nome e ${this.nome} e tenho ${this.idade} anos`)
    }
}

class Aluno extends Pessoa {
    constructor(nome, idade, curso) {
        super(nome, idade)
        this.curso = curso
    }

    estudar() {
        console.log(`Estou estudando ${this.curso}`)
    }
}

// Criando um objeto Aluno
const aluno1 = new Aluno("Gilmar", 18, "Desenvolvimento de Sistemas")

// Testando os metodos
aluno1.apresentar()
aluno1.estudar()