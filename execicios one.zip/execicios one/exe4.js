class Publicacao {
    constructor(titulo, anoPublicacao) {
        this.titulo = titulo;
        this.anoPublicacao = anoPublicacao;
    }

    exibirInformacoes() {
        console.log(`Titulo: ${this.titulo}, Ano: ${this.anoPublicacao}`);
    }
}

class Livro extends Publicacao {
    constructor(titulo, anoPublicacao, autor) {
        super(titulo, anoPublicacao);
        this.autor = autor;
    }

    exibirInformacoes() {
        super.exibirInformacoes();
        console.log(`Autor: ${this.autor}`);
    }
}

class Revista extends Publicacao {
    constructor(titulo, anoPublicacao, edicao) {
        super(titulo, anoPublicacao);
        this.edicao = edicao;
    }

    exibirInformacoes() {
        super.exibirInformacoes();
        console.log(`Edicao: ${this.edicao}`);
    }
}

console.log("\n--- Teste Questao 4 ---");

const livro = new Livro("Dom Casmurro", 1899, "Machado de Assis");

livro.exibirInformacoes();