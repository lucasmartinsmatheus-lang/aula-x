class Pessoa {
    constructor(nome, idade) {
        this.nome = nome
        this.idade = idade
    }

    apresentar() {
        console.log(`Ola! Meu nome e ${this.nome} e tenho ${this.idade} anos`)
    }
}

class Professor extends Pessoa {
    constructor(nome, idade, disciplina) {
        super(nome, idade)
        this.disciplina = disciplina
    }

    ensinar() {
        console.log(`Estou ensinando a disciplina de ${this.disciplina}`)
    }
}

// Criando um objeto Professor
const professor1 = new Professor("Carlos", 35, "Programacao")

// Testando os metodos
professor1.apresentar()
professor1.ensinar()