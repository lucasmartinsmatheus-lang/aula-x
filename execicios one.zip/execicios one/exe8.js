class Produto {
    constructor(nome, preco) {
        this.nome = nome;
        this.preco = preco;
    }

    mostrarProduto() {
        console.log(`Produto: ${this.nome} | Preco: R$ ${this.preco}`);
    }
}

class ProdutoEletronico extends Produto {
    constructor(nome, preco, garantiaMeses) {
        super(nome, preco);
        this.garantiaMeses = garantiaMeses;
    }

    mostrarProduto() {
        super.mostrarProduto();
        console.log(`Garantia: ${this.garantiaMeses} meses`);
    }
}

console.log("\n--- Teste Questao 8 ---");

const tv = new ProdutoEletronico("Smart TV", 2500, 12);
tv.mostrarProduto();