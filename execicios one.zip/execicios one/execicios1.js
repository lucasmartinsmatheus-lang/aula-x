class Pessoa {
    constructor(nome, idade) {
        this.nome = nome;
        this.idade = idade;
    }

    apresentar() {
        console.log(`Ola! Meu nome e ${this.nome} e tenho ${this.idade} anos`);
    }
}

// Criando um objeto da classe Pessoa
const pessoa1 = new Pessoa("Gilmar", 18);

// Executando o metodo
pessoa1.apresentar()