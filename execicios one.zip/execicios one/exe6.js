class Funcionario {
    constructor(nome, salario) {
        this.nome = nome;
        this.salario = salario;
    }

    mostrarDados() {
        console.log(`Funcionario: ${this.nome}, Salario: R$ ${this.salario}`);
    }
}

class Gerente extends Funcionario {
    constructor(nome, salario, departamento) {
        super(nome, salario);
        this.departamento = departamento;
    }

    autorizarCompra() {
        console.log(`Gerente ${this.nome} autorizou a compra para o setor ${this.departamento}.`);
    }
}

console.log("\n--- Teste Questao 6 ---");

const gerente = new Gerente("Alice", 8500, "TI");

gerente.mostrarDados();
gerente.autorizarCompra();