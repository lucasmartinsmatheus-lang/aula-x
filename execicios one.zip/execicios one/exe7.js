class ContaBancaria {
    constructor(titular, saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    depositar(valor) {
        this.saldo += valor;
        console.log(`Deposito de R$ ${valor} feito. Novo Saldo: R$ ${this.saldo}`);
    }

    sacar(valor) {
        if (this.saldo >= valor) {
            this.saldo -= valor;
            console.log(`Saque de R$ ${valor} efetuado. Saldo: R$ ${this.saldo}`);
        } else {
            console.log("Saldo insuficiente.");
        }
    }

    consultarSaldo() {
        console.log(`Titular: ${this.titular} | Saldo: R$ ${this.saldo}`);
    }
}

class ContaCorrente extends ContaBancaria {
    constructor(titular, saldo, limite) {
        super(titular, saldo);
        this.limite = limite;
    }

    usarLimite(valor) {
        const totalDisponivel = this.saldo + this.limite;

        if (totalDisponivel >= valor) {
            this.saldo -= valor;
            console.log(`Uso do limite/saldo de R$ ${valor}. Saldo atual: R$ ${this.saldo}`);
        } else {
            console.log("Limite excedido.");
        }
    }
}

console.log("\n--- Teste Questao 7 ---");

const conta = new ContaCorrente("Bruno", 1000, 500);

conta.consultarSaldo();
conta.usarLimite(1200);